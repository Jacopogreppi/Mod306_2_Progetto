
Diario di lavoro
##### Nikola Momcilovic, Jacopo Greppi
### Canobbio, [18.11.2016]
### Inizio ufficiale dei progetti

## Analisi

## Lavori svolti
Lavoro svolto da Nikola Momcilovic e Jacopo Greppi

Nella lezione odierna abbiamo analizzato quello che il docente richiedeva. <br>
 Abbiamo fatto un idea astratta del risultato da fare e il diagramma ER per il database da creare:

 ![Idea_progetto](img/Idea_progetto.jpg)


![Diagramma_ER](img/Diagramma_ER.jpg)

Il tutto è stato discusso con il mandante, il signor Sartori.

##  Problemi riscontrati e soluzioni adottate


##  Punto della situazione rispetto alla pianificazione
Gantt è da concludere per la prossima lezione. Altrimenti in regola.


## Programma di massima per la prossima giornata di lavoro
Estrarre tutte le attività + sottoattività, dividercele e fare il gantt.
